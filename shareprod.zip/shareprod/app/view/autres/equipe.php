<?php include_once ("app/view/layout/header.php") ?>
	<div class="content">
		<h2>Equipe</h2>
		<div class="baseline-equipe">Découvrez les créateurs de la plateforme ShareProd !</div>
		<div class="content-fondateur">
			<div class="createur">
				<div class="img-createur1"></div>
				<div class="nom-createur">Charles Guignard</div>
				<div class="role-createur">Coordinateur projet - Marketeur</div>
				<div class="descr-createur">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum distinctio libero sed ea architecto neque tempora numquam molestiae, ipsam exercitationem, nisi debitis dignissimos ad maiores aliquam repellendus laudantium quisquam, quidem.</div>
			</div>
			<div class="createur">
				<div class="img-createur2"></div>
				<div class="nom-createur">Adrien de Montgon</div>
				<div class="role-createur">Marketeur</div>
				<div class="descr-createur">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus, magnam saepe reiciendis accusamus veritatis, pariatur quis eaque atque sequi, odio reprehenderit officiis quisquam error libero tenetur nemo vel distinctio cum!</div>
			</div>
			<div class="createur">
				<div class="img-createur3"></div>
				<div class="nom-createur">David Korhonen</div>
				<div class="role-createur">Webdesigner</div>
				<div class="descr-createur">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, labore facilis placeat vel excepturi, soluta dignissimos quae esse officia impedit, vero corporis ipsam perspiciatis quod aperiam, ipsa nobis provident. Hic!</div>
			</div>
			<div class="createur">
				<div class="img-createur4"></div>
				<div class="nom-createur">Antoine Le Berre</div>
				<div class="role-createur">Développeur Web</div>
				<div class="descr-createur">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur ratione et numquam impedit perferendis. Est porro sed, ratione! Atque, consectetur? Recusandae ea, quia vitae consequuntur nisi commodi eveniet delectus ullam.</div>
			</div>
			<div class="createur">
				<div class="img-createur5"></div>
				<div class="nom-createur">Aurelien Bonnaud-Leroux</div>
				<div class="role-createur">Développeur Web</div>
				<div class="descr-createur">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus praesentium voluptatum eius tempora rem officia, repellat cum enim explicabo unde, autem fuga possimus ullam itaque culpa qui? Illo, velit, aspernatur.</div>
			</div>
		</div>
	</div>
<?php include_once ("app/view/layout/footer.php") ?>