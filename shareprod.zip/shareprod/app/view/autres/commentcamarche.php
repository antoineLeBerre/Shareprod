<?php include_once ("app/view/layout/header.php") ?>
	<div class="content">
		<h2>Comment ça marche ?</h2>
		Découvrez comment marche ShareProd en seulement 3 étapes :
		<div class="etape">
			<div class="img-etape1"></div>
			<div class="titre-ccm">Titre de la raison</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem praesentium quaerat pariatur, eius hic, quasi tempora natus rerum eaque doloribus tenetur assumenda, qui expedita impedit illo. Laudantium quos eos perspiciatis.</p>
		</div>
		<div class="etape">
			<div class="img-etape2"></div>
			<div class="titre-ccm">Titre de la raison</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem praesentium quaerat pariatur, eius hic, quasi tempora natus rerum eaque doloribus tenetur assumenda, qui expedita impedit illo. Laudantium quos eos perspiciatis.</p>
		</div>
		<div class="etape">
			<div class="img-etape3"></div>
			<div class="titre-ccm">Titre de la raison</div>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem praesentium quaerat pariatur, eius hic, quasi tempora natus rerum eaque doloribus tenetur assumenda, qui expedita impedit illo. Laudantium quos eos perspiciatis.</p>
		</div>
	</div>
<?php include_once ("app/view/layout/footer.php") ?>