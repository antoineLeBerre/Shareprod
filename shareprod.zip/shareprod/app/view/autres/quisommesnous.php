<?php include_once ("app/view/layout/header.php") ?>
	<div class="content">
	<h2>Qui sommes nous ?</h2>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex aperiam possimus nihil, aliquam nesciunt, hic animi ab consectetur incidunt eum ut harum reprehenderit fugiat maxime facilis beatae repellendus molestias voluptatibus.</p>
	</div>
<?php include_once ("app/view/layout/footer.php") ?>