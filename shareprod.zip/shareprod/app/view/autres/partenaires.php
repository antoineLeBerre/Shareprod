<?php include_once ("app/view/layout/header.php") ?>
	<div class="content">
		<h2>Nos partenaires</h2>
		<div class="listes-partenaires">
			<img src="img/bg/partenaire1.jpg" class="partenaire" alt="">
			<img src="img/bg/partenaire2.jpg" class="partenaire" alt="">
			<img src="img/bg/partenaire3.png" class="partenaire" alt="">
			<img src="img/bg/partenaire4.png" class="partenaire" alt="">
		</div>
		<div class="pourquoi-partenaire">
			<div class="img-pourquoi-partenaire"></div>
			<div class="pourquoi-partenaires-content">
				<div class="titre-partenaires">Pourquoi devenir partenaire ShareProd ?</div>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex deleniti distinctio tempora repudiandae dolores incidunt soluta blanditiis placeat non id nulla itaque pariatur earum quidem animi, sint cumque. Dolore, voluptatem.</p>
			</div>
		</div>
		<a href=""><div class="btn-partenaire btn">Contactez-nous</div></a>
	</div>
<?php include_once ("app/view/layout/footer.php") ?>