<?php include_once ("app/view/layout/header.php") ?>
	<div class="content">
		<h2>Presse</h2>
		Retrouvez tous les articles qui parlent de nous :
		<div class="article-presse">
			<a href=""><img src="img/bg/home.png" alt=""></a>
			<div class="content-article-presse">
				<div class="titre-presse">Titre</div>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint eveniet dolorum, sapiente, possimus harum saepe quod, optio voluptatem iusto incidunt.</p>
			</div>
		</div>
		<div class="article-presse">
			<a href=""><img src="img/bg/home.png" alt=""></a>
			<div class="content-article-presse">
				<div class="titre-presse">Titre</div>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint eveniet dolorum, sapiente, possimus harum saepe quod, optio voluptatem iusto incidunt.</p>
			</div>
		</div>
		<div class="article-presse">
			<a href=""><img src="img/bg/home.png" alt=""></a>
			<div class="content-article-presse">
				<div class="titre-presse">Titre</div>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint eveniet dolorum, sapiente, possimus harum saepe quod, optio voluptatem iusto incidunt.</p>
			</div>
		</div>
		<a href=""><div class="btn-presse btn">Voir plus</div></a>
	</div>
<?php include_once ("app/view/layout/footer.php") ?>