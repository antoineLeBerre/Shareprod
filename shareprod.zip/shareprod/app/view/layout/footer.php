
	<div class="footer">
		<div class="footerpart1">
			<div class="ccm">
				<div class="titre-ccm">
					<div class="img-ccm"></div>
					<div class="txt-menu">Comment ça marche ?</div>
				</div>
				<div class="footer-menu">
					<a href="?module=autres&action=commentcamarche">Comment ça marche ?</a>
					<a href="?module=autres&action=equipe">Qui sommes nous ?</a>
					<a href="?module=autres&action=faq">FAQ</a>
					<a href="?module=autres&action=cgu">CGU</a>
				</div>
			</div>
			<div class="apsp">
				<div class="titre-ap">
					<div class="img-apsp"></div>
					<div class="txt-menu">A Propos de Shareprod</div>
				</div>
				<div class="footer-menu">
					<a href="?module=autres&action=">A Propos de Shareprod</a>
					<a href="?module=autres&action=presse">Presse</a>
					<a href="?module=autres&action=partenaire">Partenaires</a>
					<a href="?module=autres&action=equipe">Equipe</a>
					<a href="?module=autres&action=contact">Contact</a>
				</div>
			</div>
		</div>
		<div class="footerpart2">
			<div class="txt-menu">Suivez-nous</div>
			<div class="rs">
				<a href=""><div class="facebook"></div></a>
				<a href=""><div class="twitter"></div></a>
				<a href=""><div class="instagram"></div></a>
			</div>
			<div class="copyright">
				Shareprod &copy; Tous droits réservés
			</div>
		</div>
	</div>
</body>
</html>