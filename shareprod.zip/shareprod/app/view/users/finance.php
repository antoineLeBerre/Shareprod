<?php include_once ("app/view/layout/header.php") ?>
	<div class="content">
		<h3>Financer un projet</h3>
		<form action="" method="" class="form-financer">
			<div class="content-form-financer">
				<div class="titre-form-financer">Soutenir ce projet</div>
				<div class="recompense-financer">
					<input type="radio" name="recompense" value="">
					Soutenir sans récompense
				</div>
				<div class="recompense-financer">
					<div class="descr-recompense">
						<input type="radio" name="recompense" value="">
						Titre de la récompense
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis, eaque, magnam amet impedit similique odio nesciunt assumenda excepturi laborum sit quisquam nemo eius iusto voluptatum doloremque quis! Veritatis, vero, ea.</p>
					</div>
					<div class="montant-recompense-financer">15€</div>
				</div>
				<div class="recompense-financer">
					<div class="descr-recompense">
						<input type="radio" name="recompense" value="">
						Titre de la récompense
						<p>Description de la récompense</p>
					</div>
					<div class="montant-recompense-financer">15€</div>
				</div>
				<div class="recompense-financer">
					<div class="descr-recompense">
						<input type="radio" name="recompense" value="">
						Titre de la récompense
						<p>Description de la récompense</p>
					</div>
					<div class="montant-recompense-financer">15€</div>
				</div>
				<input type="submit" value="Valider">
			</div>
		</form>
	</div>
<?php include_once ("app/view/layout/footer.php") ?>