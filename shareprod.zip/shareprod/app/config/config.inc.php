<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 03/03/2017
 * Time: 01:31
 */

define("DEFAULT_MODULE", "projets");
define("DEFAULT_ACTION", "index");
define("SALAGE", "shareprod2017");
define("NB_PROJETS_PAGE", 6);
