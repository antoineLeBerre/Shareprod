$(document).ready(function()
{
	$(".img-search").click(function(){
		$(".recherche input[type=search]").css({
			'transform': 'translateX(0px)',
			'opacity': '1',
		})
	})
})