// window.onload = function(){
// 	document.getElementById('list_select').onchange = function(){
// 		if (document.getElementById('list_select').value == 0) {
// 			var url = '?module=commentaires&action=admin';
// 		}
// 		else {
// 			var url = '?module=commentaires&action=admin&user='+document.getElementById('list_selec').value;
// 		}
// 	window.location = url;
// 	}
// }